#pragma once
#include "h2dRender.h"
#include "h2dMacros.h"

namespace helix2d
{
	class Camera :
		public Painter
	{
	public:

		
	};
}